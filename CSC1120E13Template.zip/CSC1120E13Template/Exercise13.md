# Week 13 Exercise – Deep vs. Shallow Copy

## Scenario

A game allows players to create a backup copy of their character before trying risky upgrades.  
The current implementation uses `Cloneable`, but players report that changing the backup sometimes changes the original character too.

Your job is to investigate the bug and fix the cloning behavior.

---

## Rules for this exercise

Work with the provided starter code.

You should:
- Run the program
- Compare the output to what you think should happen
- Identify where shallow copying is happening
- Update the code so the backup character is independent of the original

Do **not** redesign the whole program. Focus on understanding and repairing the copy behavior.

---

## Part 1: Review the Starter Code

Read the code found in the repository thoroughly. Make sure you understand:
- What each of the objects represents in the game
- What each method is expected to do

---

## Part 2: Before You Change Any Code

Answer these prediction questions:

1. After cloning, if the backup character name changes, should the original name change?
2. After cloning, if an item is removed from the backup inventory, should the original inventory change?
3. After cloning, if a new enchantment is added to the backup sword, should the original sword change?
4. After cloning, if the equipped weapon name is changed in the backup, should the original equipped weapon change?

Write down your predictions before running the program.

---

## Part 3: Debugging Questions

After running the code, answer the following:

1. Which changes affected only the backup?
2. Which changes also affected the original?
3. Which fields were copied safely?
4. Which fields are still shared between the original and the clone?
5. Why does `super.clone()` appear to work at first?

---

## Part 4: Repair the Clone Logic

Your goal is to make the backup independent from the original.

### Step A

Update `PlayerCharacter.clone()` so that the inventory list itself is copied into a new list.

After that change, run the program again.

#### Questions

1. Did removing an item from the backup inventory still affect the original?
2. Did changing an item inside the backup inventory still affect the original?
3. What does that tell you about copying a list of objects?

---

### Step B

Update `Item.clone()` so that its `enchantments` list is also copied correctly.

---

### Step C

Update `PlayerCharacter.clone()` so that each `Item` in the inventory is cloned.

---

## Part 5: The Interesting Pitfall

In the original object graph, `equippedWeapon` refers to the same `Item` object as the sword stored in `inventory`.

A correct deep copy should preserve that relationship.

That means:
- In the clone, `equippedWeapon` should refer to the cloned sword
- Not the original sword
- And not a second separate sword clone

### Think about this

If you clone all inventory items and then separately clone `equippedWeapon`, what problem do you create?

---

## Part 6: Reflection

Answer these questions in 2–4 sentences each:

1. What is the difference between shallow copying and deep copying?
2. Why is `Cloneable` easy to misuse?
3. What makes object graphs harder to copy than single objects?
4. Would a copy constructor or factory method be clearer here? Why or why not?
