/*
 * Course: CSC1120
 * Exercise 13 Tests
 */

package exercises.week13;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class DeepCopyTests {

    @Test
    void cloneCreatesNewObject() {
        Exercise13.PlayerCharacter original = TestFactory.createCharacter();
        Exercise13.PlayerCharacter clone = original.clone();

        Assertions.assertNotSame(original, clone);
    }

    @Test
    void inventoryListIsNotShared() {
        Exercise13.PlayerCharacter original = TestFactory.createCharacter();
        Exercise13.PlayerCharacter clone = original.clone();

        Assertions.assertNotSame(original.getInventory(), clone.getInventory());
    }

    @Test
    void itemsAreNotShared() {
        Exercise13.PlayerCharacter original = TestFactory.createCharacter();
        Exercise13.PlayerCharacter clone = original.clone();

        Exercise13.Item originalItem = original.getInventory().getFirst();
        Exercise13.Item clonedItem = clone.getInventory().getFirst();

        Assertions.assertNotSame(originalItem, clonedItem);
    }

    @Test
    void enchantmentsAreNotShared() {
        Exercise13.PlayerCharacter original = TestFactory.createCharacter();
        Exercise13.PlayerCharacter clone = original.clone();

        Exercise13.Enchantment originalEnchantment =
                original.getInventory().getFirst().getEnchantments().getFirst();
        Exercise13.Enchantment clonedEnchantment =
                clone.getInventory().getFirst().getEnchantments().getFirst();

        Assertions.assertNotSame(originalEnchantment, clonedEnchantment);
    }

    @Test
    void modifyingCloneDoesNotAffectOriginal() {
        Exercise13.PlayerCharacter original = TestFactory.createCharacter();
        Exercise13.PlayerCharacter clone = original.clone();

        clone.getInventory().getFirst().setName("Modified");

        String originalName = original.getInventory().getFirst().getName();
        String clonedName = clone.getInventory().getFirst().getName();

        Assertions.assertNotEquals(originalName, clonedName);
    }

    @Test
    void removingItemFromCloneDoesNotAffectOriginal() {
        Exercise13.PlayerCharacter original = TestFactory.createCharacter();
        Exercise13.PlayerCharacter clone = original.clone();

        clone.getInventory().removeFirst();

        Assertions.assertEquals(2, original.getInventory().size());
        Assertions.assertEquals(1, clone.getInventory().size());
    }

    @Test
    void equippedWeaponPointsToSameClonedItem() {
        Exercise13.PlayerCharacter original = TestFactory.createCharacter();
        Exercise13.PlayerCharacter clone = original.clone();

        Exercise13.Item clonedInventoryItem = clone.getInventory().getFirst();
        Exercise13.Item clonedEquipped = clone.getEquippedWeapon();

        Assertions.assertSame(clonedInventoryItem, clonedEquipped);
    }

    @Test
    void cloneDoesNotReferenceOriginalObjects() {
        Exercise13.PlayerCharacter original = TestFactory.createCharacter();
        Exercise13.PlayerCharacter clone = original.clone();

        Exercise13.Item originalItem = original.getInventory().getFirst();
        Exercise13.Item clonedItem = clone.getInventory().getFirst();

        Assertions.assertNotSame(originalItem, clonedItem);
    }

    static class TestFactory {

        static Exercise13.PlayerCharacter createCharacter() {
            Exercise13.Enchantment fire = new Exercise13.Enchantment("Fire", 4);
            Exercise13.Enchantment ice = new Exercise13.Enchantment("Ice", 2);

            Exercise13.Item sword = new Exercise13.Item("Sword");
            sword.addEnchantment(fire);

            Exercise13.Item potion = new Exercise13.Item("Potion");
            potion.addEnchantment(ice);

            Exercise13.PlayerCharacter pc = new Exercise13.PlayerCharacter("Aria");
            pc.addItem(sword);
            pc.addItem(potion);
            pc.setEquippedWeapon(sword);

            return pc;
        }
    }
}



