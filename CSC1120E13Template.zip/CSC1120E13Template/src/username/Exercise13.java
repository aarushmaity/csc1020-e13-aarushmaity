/*
 * Course: CSC-1120
 * ASSIGNMENT
 * CLASS
 * Name: TODO
 * Last Updated: TODO
 */
package username;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple game exercise to learn about cloning
 */
public class Exercise13 {
    static void main() {
        final int firePower = 5;
        final int icePower = 2;
        final int originalSwordIndex = 0;
        final int originalPotionIndex = 1;

        Enchantment fire = new Enchantment("Fire", firePower);
        Enchantment ice = new Enchantment("Ice", icePower);

        Item sword = new Item("Sword");
        sword.addEnchantment(fire);

        Item potion = new Item("Potion");
        potion.addEnchantment(ice);

        PlayerCharacter original = new PlayerCharacter("Aria");
        original.addItem(sword);
        original.addItem(potion);
        original.setEquippedWeapon(sword);

        PlayerCharacter backup = original.clone();

        backup.setName("Backup-Aria");
        backup.getInventory().remove(originalPotionIndex);
        backup.getInventory().get(originalSwordIndex).addEnchantment(new Enchantment("Poison", 3));
        backup.getEquippedWeapon().setName("Corrupted Sword");

        System.out.println("Original:");
        System.out.println(original);
        System.out.println();

        System.out.println("Backup:");
        System.out.println(backup);
    }

    static class Enchantment implements Cloneable {
        private final String name;
        private final int bonusPower;

        private Enchantment(String name, int bonusPower) {
            this.name = name;
            this.bonusPower = bonusPower;
        }

        public String getName() {
            return name;
        }

        public int getBonusPower() {
            return bonusPower;
        }

        @Override
        public Enchantment clone() {
            try {
                return (Enchantment) super.clone();
            } catch (CloneNotSupportedException exception) {
                throw new AssertionError(exception);
            }
        }

        @Override
        public String toString() {
            return name + "+" + bonusPower;
        }
    }

    static class Item implements Cloneable {
        private String name;
        private final List<Enchantment> enchantments;

        private Item(String name) {
            this.name = name;
            this.enchantments = new ArrayList<>();
        }

        public void addEnchantment(Enchantment enchantment) {
            enchantments.add(enchantment);
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public List<Enchantment> getEnchantments() {
            return enchantments;
        }

        @Override
        public Item clone() {
            try {
                return (Item) super.clone();
            } catch (CloneNotSupportedException exception) {
                throw new AssertionError(exception);
            }
        }

        @Override
        public String toString() {
            return name + " " + enchantments;
        }
    }

    static class PlayerCharacter implements Cloneable {
        private String name;
        private final List<Item> inventory;
        private Item equippedWeapon;

        private PlayerCharacter(String name) {
            this.name = name;
            this.inventory = new ArrayList<>();
        }

        public void addItem(Item item) {
            inventory.add(item);
        }

        public List<Item> getInventory() {
            return inventory;
        }

        public Item getEquippedWeapon() {
            return equippedWeapon;
        }

        public void setEquippedWeapon(Item equippedWeapon) {
            this.equippedWeapon = equippedWeapon;
        }

        public void setName(String name) {
            this.name = name;
        }

        @Override
        public PlayerCharacter clone() {
            try {
                return (PlayerCharacter) super.clone();
            } catch (CloneNotSupportedException exception) {
                throw new AssertionError(exception);
            }
        }

        @Override
        public String toString() {
            return "name=" + name
                    + ", inventory=" + inventory
                    + ", equippedWeapon=" + equippedWeapon;
        }
    }
}

